from gptravel.core.services.geocoder import GeoCoder

geo_decoder = GeoCoder()
