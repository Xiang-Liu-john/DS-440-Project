class HuggingFaceError(Exception):
    pass
