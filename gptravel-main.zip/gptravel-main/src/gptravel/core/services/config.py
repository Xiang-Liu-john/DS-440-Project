ACTIVITIES_LABELS = [
    "mountain",
    "sea",
    "museum",
    "monument",
    "food",
    "relax",
    "sport",
    "culture",
    "shopping",
    "transport",
]
